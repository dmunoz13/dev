/*
 * Translated default messages for bootstrap-select.
 * Locale: IT (Italian; italiano)
 * Region: IT (Italy; Italia)
 * Author: Michele Beltrame <mb@cattlegrid.info>
 */
(function($) {
	$.fn.selectpicker.defaults = {
        style: 'btn-default',
        size: 'auto',
        title: null,
        selectedTextFormat : 'values',
        noneSelectedText : 'Nessuna selezione',
		noneResultsText : 'Nessun risultato',
		countSelectedText : 'Selezionati {0} di {1}',
        maxOptionsText: ['Limite raggiunto ({n} {var} max)', 'Limite del gruppo raggiunto ({n} {var} max)', ['elementi','elemento']],
        width: false,
        container: false,
        hideDisabled: false,
        showSubtext: false,
        showIcon: true,
        showContent: true,
        dropupAuto: true,
        header: false,
        liveSearch: false,
        actionsBox: false,
        multipleSeparator: ', ',
        iconBase: 'glyphicon',
        tickIcon: 'glyphicon-ok',
        maxOptions: false
    };
}(jQuery));
